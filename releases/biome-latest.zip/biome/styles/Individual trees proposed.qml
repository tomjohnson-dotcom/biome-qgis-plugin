<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingTol="1" simplifyMaxScale="1" readOnly="0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" simplifyAlgorithm="0" labelsEnabled="0" simplifyDrawingHints="0" simplifyLocal="1" maxScale="0" minScale="1e+08" version="3.8.1-Zanzibar">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <renderer-v2 type="RuleRenderer" forceraster="0" symbollevels="0" enableorderby="0">
    <rules key="{ca11dccd-0ed7-41a8-a515-bbfbf895245d}">
      <rule symbol="0" label="Proposed Large Urban Tree" key="{fd01748b-d060-4d2d-93c5-0fa0b14d4f3d}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Large' AND  &quot;Proposed Rural or Urban Tree&quot;  =  'Urban tree' "/>
      <rule symbol="1" label="Proposed Large Rural Tree" key="{781b5450-b308-4588-b56c-4d7965059821}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Large' AND  &quot;Proposed Rural or Urban Tree&quot;  =  'Rural tree' "/>
        <rule symbol="6" label="Proposed Very Large Urban Tree" key="{c4df5ac0-c75c-4796-93aa-737619de57fa}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Very Large' AND  &quot;Proposed Rural or Urban Tree&quot;  =  'Urban tree' "/>
        <rule symbol="7" label="Proposed Very Large Rural Tree" key="{c832538a-008a-4a88-b16e-c8178176ea4e}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Very Large' AND  &quot;Proposed Rural or Urban Tree&quot;  =  'Rural tree' "/>
      <rule symbol="2" label="Proposed Medium Urban Tree" key="{d15589ab-76e2-47e1-90be-3e3cc7ff9dc8}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Medium' AND  &quot;Proposed Rural or Urban Tree&quot; =  'Urban tree' "/>
      <rule symbol="3" label="Proposed Medium Rural Tree" key="{49aa5c16-8f6a-452d-9884-3e8e63cb2d2a}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Medium' AND  &quot;Proposed Rural or Urban Tree&quot; =  'Rural tree' "/>
      <rule symbol="4" label="Proposed Small Urban Tree" key="{9b3b5920-3c41-42f6-a285-e94d101e886f}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Small' AND  &quot;Proposed Rural or Urban Tree&quot; =  'Urban tree' "/>
      <rule symbol="5" label="Proposed Small Rural Tree" key="{5edfa61a-d536-4509-a9e6-8f093bb88052}" filter=" &quot;Retention Category&quot;  &lt;> 'Lost' AND   &quot;Proposed Tree Size&quot;  = 'Small' AND  &quot;Proposed Rural or Urban Tree&quot; =  'Rural tree' "/>
    </rules>
                    <symbols>
      <symbol type="marker" name="0" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="7.8"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="1" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="7.8"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="2" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="5.6"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="3" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="5.6"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="4" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="3.0"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="5" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="3.0"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="6" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="9.8"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="marker" name="7" clip_to_extent="1" alpha="1" force_rhr="0">
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <prop k="angle" v="0"/>
          <prop k="color" v="245,196,23,255"/>
          <prop k="horizontal_anchor_point" v="1"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="name" v="circle"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="99,56,6,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="scale_method" v="diameter"/>
          <prop k="size" v="9.8"/>
          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="size_unit" v="MM"/>
          <prop k="vertical_anchor_point" v="1"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <customproperties>
    <property key="dualview/previewExpressions" value="fid"/>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory lineSizeScale="3x:0,0,0,0,0,0" penAlpha="255" maxScaleDenominator="1e+08" diagramOrientation="Up" barWidth="5" rotationOffset="270" lineSizeType="MM" height="15" labelPlacementMethod="XHeight" backgroundColor="#ffffff" scaleDependency="Area" sizeType="MM" penWidth="0" minScaleDenominator="0" opacity="1" minimumSize="0" enabled="0" scaleBasedVisibility="0" backgroundAlpha="255" sizeScale="3x:0,0,0,0,0,0" penColor="#000000" width="15">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute field="" label="" color="#000000"/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" dist="0" linePlacementFlags="18" showAll="1" zIndex="0" placement="0" priority="0">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <fieldConfiguration>
    <field name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Tree Ref">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Baseline Tree Size">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Baseline Condition">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Baseline Strategic Significance">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Baseline Tree Type">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Retention Category">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Category">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="Newly Planted" value="Newly Planted"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Existing" value="Existing"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Proposed Tree Size">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Condition">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Strategic Significance">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Tree Type">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Location">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="On-site" value="On-site"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="Off-site" value="Off-site"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat Created/Enhanced in advance/years">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="0" value="0"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="1" value="1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="2" value="2"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="3" value="3"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="4" value="4"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="5" value="5"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="6" value="6"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="7" value="7"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="8" value="8"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="9" value="9"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="10" value="10"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="11" value="11"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="12" value="12"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="13" value="13"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="14" value="14"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="15" value="15"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="16" value="16"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="17" value="17"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="18" value="18"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="19" value="19"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="20" value="20"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="21" value="21"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="22" value="22"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="23" value="23"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="24" value="24"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="25" value="25"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="26" value="26"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="27" value="27"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="28" value="28"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="29" value="29"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="30" value="30"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="30+" value="30+"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Delay in starting habitat creation/enhancement in years">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" name="0" value="0"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="1" value="1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="2" value="2"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="3" value="3"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="4" value="4"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="5" value="5"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="6" value="6"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="7" value="7"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="8" value="8"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="9" value="9"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="10" value="10"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="11" value="11"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="12" value="12"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="13" value="13"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="14" value="14"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="15" value="15"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="16" value="16"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="17" value="17"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="18" value="18"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="19" value="19"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="20" value="20"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="21" value="21"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="22" value="22"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="23" value="23"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="24" value="24"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="25" value="25"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="26" value="26"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="27" value="27"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="28" value="28"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="29" value="29"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="30" value="30"/>
              </Option>
              <Option type="Map">
                <Option type="QString" name="30+" value="30+"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Spatial risk category">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Site Name">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Survey Date">
      <editWidget type="DateTime">
        <config>
          <Option type="Map">
            <Option type="bool" name="allow_null" value="true"/>
            <Option type="bool" name="calendar_popup" value="true"/>
            <Option type="QString" name="display_format" value="yyyy-MM-dd"/>
            <Option type="QString" name="field_format" value="yyyy-MM-dd"/>
            <Option type="bool" name="field_iso_format" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Survey Details">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Comment">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Mapped by">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Company">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Base Map">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Count">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" name="AllowNull" value="false"/>
            <Option type="int" name="Max" value="2147483647"/>
            <Option type="int" name="Min" value="-2147483648"/>
            <Option type="int" name="Precision" value="0"/>
            <Option type="int" name="Step" value="1"/>
            <Option type="QString" name="Style" value="SpinBox"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Baseline Rural or Urban Tree">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Rural or Urban Tree">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="Tree Ref" index="1" name=""/>
    <alias field="Baseline Tree Size" index="2" name=""/>
    <alias field="Baseline Condition" index="3" name=""/>
    <alias field="Baseline Strategic Significance" index="4" name=""/>
    <alias field="Baseline Tree Type" index="5" name=""/>
    <alias field="Retention Category" index="6" name=""/>
    <alias field="Category" index="7" name=""/>
    <alias field="Proposed Tree Size" index="8" name=""/>
    <alias field="Proposed Condition" index="9" name=""/>
    <alias field="Proposed Strategic Significance" index="10" name=""/>
    <alias field="Proposed Tree Type" index="11" name=""/>
    <alias field="Location" index="12" name=""/>
    <alias field="Habitat Created/Enhanced in advance/years" index="13" name=""/>
    <alias field="Delay in starting habitat creation/enhancement in years" index="14" name=""/>
    <alias field="Spatial risk category" index="15" name=""/>
    <alias field="Site Name" index="16" name=""/>
    <alias field="Survey Date" index="17" name=""/>
    <alias field="Survey Details" index="18" name=""/>
    <alias field="Comment" index="19" name=""/>
    <alias field="Mapped by" index="20" name=""/>
    <alias field="Company" index="21" name=""/>
    <alias field="Base Map" index="22" name=""/>
    <alias field="Count" index="23" name=""/>
    <alias field="Baseline Rural or Urban Tree" index="24" name=""/>
    <alias field="Proposed Rural or Urban Tree" index="25" name=""/>
  </aliases>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <defaults>
    <default field="fid" expression="" applyOnUpdate="0"/>
    <default field="Tree Ref" expression="'Null'" applyOnUpdate="0"/>
    <default field="Baseline Tree Size" expression="'Null'" applyOnUpdate="0"/>
    <default field="Baseline Condition" expression="'Null'" applyOnUpdate="0"/>
    <default field="Baseline Strategic Significance" expression="'Null'" applyOnUpdate="0"/>
    <default field="Baseline Tree Type" expression="'Null'" applyOnUpdate="0"/>
    <default field="Retention Category" expression="'Null'" applyOnUpdate="0"/>
    <default field="Category" expression="'Null'" applyOnUpdate="0"/>
    <default field="Proposed Tree Size" expression="'Null'" applyOnUpdate="0"/>
    <default field="Proposed Condition" expression="'Null'" applyOnUpdate="0"/>
    <default field="Proposed Strategic Significance" expression="'Null'" applyOnUpdate="0"/>
    <default field="Proposed Tree Type" expression="'Null'" applyOnUpdate="0"/>
    <default field="Location" expression="" applyOnUpdate="0"/>
    <default field="Habitat Created/Enhanced in advance/years" expression="0" applyOnUpdate="0"/>
    <default field="Delay in starting habitat creation/enhancement in years" expression="0" applyOnUpdate="0"/>
    <default field="Spatial risk category" expression="'N/A'" applyOnUpdate="0"/>
    <default field="Site Name" expression="" applyOnUpdate="0"/>
    <default field="Survey Date" expression="" applyOnUpdate="0"/>
    <default field="Survey Details" expression="" applyOnUpdate="0"/>
    <default field="Comment" expression="" applyOnUpdate="0"/>
    <default field="Mapped by" expression="" applyOnUpdate="0"/>
    <default field="Company" expression="" applyOnUpdate="0"/>
    <default field="Base Map" expression="" applyOnUpdate="0"/>
    <default field="Count" expression="1" applyOnUpdate="1"/>
    <default field="Baseline Rural or Urban Tree" expression="" applyOnUpdate="0"/>
    <default field="Proposed Rural or Urban Tree" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="fid" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" field="Tree Ref" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Baseline Tree Size" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Baseline Condition" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Baseline Strategic Significance" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Baseline Tree Type" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Retention Category" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Category" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Proposed Tree Size" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Proposed Condition" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Proposed Strategic Significance" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Proposed Tree Type" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Location" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Habitat Created/Enhanced in advance/years" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Delay in starting habitat creation/enhancement in years" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Spatial risk category" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Site Name" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Survey Date" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Survey Details" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Comment" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Mapped by" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Company" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Base Map" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Count" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Baseline Rural or Urban Tree" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="Proposed Rural or Urban Tree" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" exp="" desc=""/>
    <constraint field="Tree Ref" exp="" desc=""/>
    <constraint field="Baseline Tree Size" exp="" desc=""/>
    <constraint field="Baseline Condition" exp="" desc=""/>
    <constraint field="Baseline Strategic Significance" exp="" desc=""/>
    <constraint field="Baseline Tree Type" exp="" desc=""/>
    <constraint field="Retention Category" exp="" desc=""/>
    <constraint field="Category" exp="" desc=""/>
    <constraint field="Proposed Tree Size" exp="" desc=""/>
    <constraint field="Proposed Condition" exp="" desc=""/>
    <constraint field="Proposed Strategic Significance" exp="" desc=""/>
    <constraint field="Proposed Tree Type" exp="" desc=""/>
    <constraint field="Location" exp="" desc=""/>
    <constraint field="Habitat Created/Enhanced in advance/years" exp="" desc=""/>
    <constraint field="Delay in starting habitat creation/enhancement in years" exp="" desc=""/>
    <constraint field="Spatial risk category" exp="" desc=""/>
    <constraint field="Site Name" exp="" desc=""/>
    <constraint field="Survey Date" exp="" desc=""/>
    <constraint field="Survey Details" exp="" desc=""/>
    <constraint field="Comment" exp="" desc=""/>
    <constraint field="Mapped by" exp="" desc=""/>
    <constraint field="Company" exp="" desc=""/>
    <constraint field="Base Map" exp="" desc=""/>
    <constraint field="Count" exp="" desc=""/>
    <constraint field="Baseline Rural or Urban Tree" exp="" desc=""/>
    <constraint field="Proposed Rural or Urban Tree" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns>
      <column type="field" width="-1" name="fid" hidden="1"/>
      <column type="field" width="-1" name="Category" hidden="0"/>
      <column type="field" width="-1" name="Tree Ref" hidden="0"/>
      <column type="field" width="-1" name="Baseline Rural or Urban Tree" hidden="0"/>
      <column type="field" width="-1" name="Baseline Tree Size" hidden="0"/>
      <column type="field" width="-1" name="Baseline Tree Type" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
      <column type="field" width="-1" name="Baseline Condition" hidden="0"/>
      <column type="field" width="-1" name="Baseline Strategic Significance" hidden="0"/>
      <column type="field" width="-1" name="Retention Category" hidden="0"/>
      <column type="field" width="-1" name="Proposed Rural or Urban Tree" hidden="0"/>
      <column type="field" width="-1" name="Proposed Tree Size" hidden="0"/>
      <column type="field" width="-1" name="Proposed Tree Type" hidden="0"/>
      <column type="field" width="-1" name="Proposed Condition" hidden="0"/>
      <column type="field" width="-1" name="Proposed Strategic Significance" hidden="0"/>
      <column type="field" width="-1" name="Habitat Created/Enhanced in advance/years" hidden="0"/>
      <column type="field" width="100" name="Delay in starting habitat creation/enhancement in years" hidden="0"/>
      <column type="field" width="-1" name="Location" hidden="0"/>
      <column type="field" width="35" name="Spatial risk category" hidden="0"/>
      <column type="field" width="-1" name="Site Name" hidden="0"/>
      <column type="field" width="-1" name="Survey Date" hidden="0"/>
      <column type="field" width="-1" name="Survey Details" hidden="0"/>
      <column type="field" width="-1" name="Comment" hidden="0"/>
      <column type="field" width="-1" name="Mapped by" hidden="0"/>
      <column type="field" width="-1" name="Company" hidden="0"/>
      <column type="field" width="-1" name="Base Map" hidden="0"/>
      <column type="field" width="-1" name="Count" hidden="0"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <attributeEditorContainer showLabel="1" visibilityExpressionEnabled="0" name="Baseline" groupBox="0" visibilityExpression="" columnCount="1">
      <attributeEditorField showLabel="1" index="7" name="Category"/>
      <attributeEditorField showLabel="1" index="24" name="Baseline Rural or Urban Tree"/>
      <attributeEditorField showLabel="1" index="1" name="Tree Ref"/>
      <attributeEditorField showLabel="1" index="2" name="Baseline Tree Size"/>
      <attributeEditorField showLabel="1" index="5" name="Baseline Tree Type"/>
      <attributeEditorField showLabel="1" index="3" name="Baseline Condition"/>
      <attributeEditorField showLabel="1" index="4" name="Baseline Strategic Significance"/>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" visibilityExpressionEnabled="0" name="Proposed" groupBox="0" visibilityExpression="" columnCount="1">
      <attributeEditorField showLabel="1" index="6" name="Retention Category"/>
      <attributeEditorField showLabel="1" index="25" name="Proposed Rural or Urban Tree"/>
      <attributeEditorField showLabel="1" index="8" name="Proposed Tree Size"/>
      <attributeEditorField showLabel="1" index="11" name="Proposed Tree Type"/>
      <attributeEditorField showLabel="1" index="9" name="Proposed Condition"/>
      <attributeEditorField showLabel="1" index="10" name="Proposed Strategic Significance"/>
      <attributeEditorField showLabel="1" index="13" name="Habitat Created/Enhanced in advance/years"/>
      <attributeEditorField showLabel="1" index="14" name="Delay in starting habitat creation/enhancement in years"/>
      <attributeEditorField showLabel="1" index="12" name="Location"/>
      <attributeEditorField showLabel="1" index="15" name="Spatial risk category"/>
    </attributeEditorContainer>
    <attributeEditorContainer showLabel="1" visibilityExpressionEnabled="0" name="Assessment Details" groupBox="0" visibilityExpression="" columnCount="1">
      <attributeEditorField showLabel="1" index="22" name="Base Map"/>
      <attributeEditorField showLabel="1" index="21" name="Company"/>
      <attributeEditorField showLabel="1" index="20" name="Mapped by"/>
      <attributeEditorField showLabel="1" index="19" name="Comment"/>
      <attributeEditorField showLabel="1" index="18" name="Survey Details"/>
      <attributeEditorField showLabel="1" index="17" name="Survey Date"/>
      <attributeEditorField showLabel="1" index="16" name="Site Name"/>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="Base Map"/>
    <field editable="1" name="Baseline Condition"/>
    <field editable="1" name="Baseline Rural or Urban Tree"/>
    <field editable="1" name="Baseline Strategic Significance"/>
    <field editable="1" name="Baseline Tree Size"/>
    <field editable="1" name="Baseline Tree Type"/>
    <field editable="1" name="Category"/>
    <field editable="1" name="Comment"/>
    <field editable="1" name="Company"/>
    <field editable="0" name="Count"/>
    <field editable="1" name="Delay in starting habitat creation/enhancement in years"/>
    <field editable="1" name="Habitat Created/Enhanced in advance/years"/>
    <field editable="1" name="Location"/>
    <field editable="1" name="Mapped by"/>
    <field editable="1" name="Proposed Condition"/>
    <field editable="1" name="Proposed Rural or Urban Tree"/>
    <field editable="1" name="Proposed Strategic Significance"/>
    <field editable="1" name="Proposed Tree Size"/>
    <field editable="1" name="Proposed Tree Type"/>
    <field editable="1" name="Retention Category"/>
    <field editable="1" name="Rural or Urban Tree"/>
    <field editable="1" name="Site Name"/>
    <field editable="1" name="Spatial risk category"/>
    <field editable="1" name="Survey Date"/>
    <field editable="1" name="Survey Details"/>
    <field editable="1" name="Tree Ref"/>
    <field editable="1" name="Tree Size"/>
    <field editable="1" name="Tree Type"/>
    <field editable="0" name="Urban Tree Fixed Criteria - post_Baseline Distinctivness"/>
    <field editable="0" name="Urban Tree Fixed Criteria - post_Baseline UKHAB"/>
    <field editable="0" name="Urban Tree Fixed Criteria - post_Broad Habitat"/>
    <field editable="0" name="Urban Tree Fixed Criteria - post_Habitat"/>
    <field editable="0" name="Urban Tree Fixed Criteria - pre_Baseline Distinctivness"/>
    <field editable="0" name="Urban Tree Fixed Criteria - pre_Baseline UKHAB"/>
    <field editable="0" name="Urban Tree Fixed Criteria - pre_Broad Habitat"/>
    <field editable="0" name="Urban Tree Fixed Criteria - pre_Count"/>
    <field editable="0" name="Urban Tree Fixed Criteria - pre_Habitat"/>
    <field editable="1" name="fid"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="Base Map"/>
    <field labelOnTop="0" name="Baseline Condition"/>
    <field labelOnTop="0" name="Baseline Rural or Urban Tree"/>
    <field labelOnTop="0" name="Baseline Strategic Significance"/>
    <field labelOnTop="0" name="Baseline Tree Size"/>
    <field labelOnTop="0" name="Baseline Tree Type"/>
    <field labelOnTop="0" name="Category"/>
    <field labelOnTop="0" name="Comment"/>
    <field labelOnTop="0" name="Company"/>
    <field labelOnTop="0" name="Count"/>
    <field labelOnTop="0" name="Delay in starting habitat creation/enhancement in years"/>
    <field labelOnTop="0" name="Habitat Created/Enhanced in advance/years"/>
    <field labelOnTop="0" name="Location"/>
    <field labelOnTop="0" name="Mapped by"/>
    <field labelOnTop="0" name="Proposed Condition"/>
    <field labelOnTop="0" name="Proposed Rural or Urban Tree"/>
    <field labelOnTop="0" name="Proposed Strategic Significance"/>
    <field labelOnTop="0" name="Proposed Tree Size"/>
    <field labelOnTop="0" name="Proposed Tree Type"/>
    <field labelOnTop="0" name="Retention Category"/>
    <field labelOnTop="0" name="Rural or Urban Tree"/>
    <field labelOnTop="0" name="Site Name"/>
    <field labelOnTop="0" name="Spatial risk category"/>
    <field labelOnTop="0" name="Survey Date"/>
    <field labelOnTop="0" name="Survey Details"/>
    <field labelOnTop="0" name="Tree Ref"/>
    <field labelOnTop="0" name="Tree Size"/>
    <field labelOnTop="0" name="Tree Type"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - post_Baseline Distinctivness"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - post_Baseline UKHAB"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - post_Broad Habitat"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - post_Habitat"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - pre_Baseline Distinctivness"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - pre_Baseline UKHAB"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - pre_Broad Habitat"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - pre_Count"/>
    <field labelOnTop="0" name="Urban Tree Fixed Criteria - pre_Habitat"/>
    <field labelOnTop="0" name="fid"/>
  </labelOnTop>
  <widgets/>
  <previewExpression>fid</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
