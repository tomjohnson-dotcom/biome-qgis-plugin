<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" simplifyDrawingTol="1" labelsEnabled="0" simplifyAlgorithm="0" minScale="1e+08" simplifyMaxScale="1" version="3.10.11-A Coruña" styleCategories="AllStyleCategories" simplifyDrawingHints="1" simplifyLocal="1" maxScale="0" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <renderer-v2 attr="Retention Category" symbollevels="0" enableorderby="0" type="categorizedSymbol" forceraster="0">
    <categories>
      <category label="Enhanced" value="Enhanced" render="true" symbol="0"/>
      <category label="Retained" value="Retained" render="true" symbol="1"/>
      <category label="Lost" value="Lost" render="true" symbol="2"/>
    </categories>
    <symbols>
      <symbol type="fill" force_rhr="0" name="0" clip_to_extent="1" alpha="1">
        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="color" v="92,1,115,255"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="92,1,115,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.26"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="style" v="solid"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" force_rhr="0" name="1" clip_to_extent="1" alpha="1">
        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="color" v="32,144,141,255"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="33,144,141,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.26"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="style" v="solid"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" force_rhr="0" name="2" clip_to_extent="1" alpha="1">
        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="color" v="253,231,37,255"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="253,231,37,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.26"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="style" v="solid"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <source-symbol>
      <symbol type="fill" force_rhr="0" name="0" clip_to_extent="1" alpha="1">
        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="color" v="166,206,227,255"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="offset" v="0,0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="outline_color" v="35,35,35,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.26"/>
          <prop k="outline_width_unit" v="MM"/>
          <prop k="style" v="solid"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </source-symbol>
    <colorramp type="gradient" name="[source]">
      <prop k="color1" v="68,1,84,255"/>
      <prop k="color2" v="253,231,37,255"/>
      <prop k="discrete" v="0"/>
      <prop k="rampType" v="gradient"/>
      <prop k="stops" v="0.0196078;70,8,92,255:0.0392157;71,16,99,255:0.0588235;72,23,105,255:0.0784314;72,29,111,255:0.0980392;72,36,117,255:0.117647;71,42,122,255:0.137255;70,48,126,255:0.156863;69,55,129,255:0.176471;67,61,132,255:0.196078;65,66,135,255:0.215686;63,72,137,255:0.235294;61,78,138,255:0.254902;58,83,139,255:0.27451;56,89,140,255:0.294118;53,94,141,255:0.313725;51,99,141,255:0.333333;49,104,142,255:0.352941;46,109,142,255:0.372549;44,113,142,255:0.392157;42,118,142,255:0.411765;41,123,142,255:0.431373;39,128,142,255:0.45098;37,132,142,255:0.470588;35,137,142,255:0.490196;33,142,141,255:0.509804;32,146,140,255:0.529412;31,151,139,255:0.54902;30,156,137,255:0.568627;31,161,136,255:0.588235;33,165,133,255:0.607843;36,170,131,255:0.627451;40,174,128,255:0.647059;46,179,124,255:0.666667;53,183,121,255:0.686275;61,188,116,255:0.705882;70,192,111,255:0.72549;80,196,106,255:0.745098;90,200,100,255:0.764706;101,203,94,255:0.784314;112,207,87,255:0.803922;124,210,80,255:0.823529;137,213,72,255:0.843137;149,216,64,255:0.862745;162,218,55,255:0.882353;176,221,47,255:0.901961;189,223,38,255:0.921569;202,225,31,255:0.941176;216,226,25,255:0.960784;229,228,25,255:0.980392;241,229,29,255"/>
    </colorramp>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <property key="dualview/previewExpressions" value="&quot;Baseline Broad Habitat Type&quot;"/>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>0.6</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory opacity="1" backgroundAlpha="255" lineSizeType="MM" height="15" lineSizeScale="3x:0,0,0,0,0,0" maxScaleDenominator="1e+08" scaleBasedVisibility="0" enabled="0" labelPlacementMethod="XHeight" rotationOffset="270" diagramOrientation="Up" penWidth="0" minScaleDenominator="0" sizeType="MM" minimumSize="0" sizeScale="3x:0,0,0,0,0,0" backgroundColor="#ffffff" barWidth="5" penColor="#000000" penAlpha="255" width="15" scaleDependency="Area">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute label="" field="" color="#000000"/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings dist="0" obstacle="0" linePlacementFlags="18" priority="0" placement="1" zIndex="0" showAll="1">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option type="double" value="0" name="allowedGapsBuffer"/>
        <Option type="bool" value="false" name="allowedGapsEnabled"/>
        <Option type="QString" value="" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <fieldConfiguration>
    <field name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Parcel Ref">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Baseline Broad Habitat Type">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="Cropland" name="Cropland"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Grassland" name="Grassland"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Heathland and shrub" name="Heathland and shrub"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Lakes" name="Lakes"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Sparsely vegetated land" name="Sparsely vegetated land"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Urban" name="Urban"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Wetland" name="Wetland"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Woodland and forest" name="Woodland and forest"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Coastal lagoons" name="Coastal lagoons"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Rocky shore" name="Rocky shore"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Coastal saltmarsh" name="Coastal saltmarsh"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Intertidal sediment" name="Intertidal sediment"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Intertidal" name="Intertidal"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Baseline Habitat Type">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Area">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option type="bool" value="true" name="AllowNull"/>
            <Option type="int" value="2147483647" name="Max"/>
            <Option type="int" value="-2147483648" name="Min"/>
            <Option type="int" value="0" name="Precision"/>
            <Option type="int" value="1" name="Step"/>
            <Option type="QString" value="SpinBox" name="Style"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Baseline Condition">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Baseline Strategic Significance">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="Within area formally identified in local strategy" name="Within area formally identified in local strategy"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Location ecologically desirable but not in local strategy" name="Location ecologically desirable but not in local strategy"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Area/compensation not in local strategy/ no local strategy" name="Area/compensation not in local strategy/ no local strategy"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Retention Category">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="Lost" name="Lost"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Retained" name="Retained"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Enhanced" name="Enhanced"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Proposed Broad Habitat Type">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Habitat Type">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Condition">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Proposed Strategic Significance">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="Within area formally identified in local strategy" name="Within area formally identified in local strategy"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Location ecologically desirable but not in local strategy" name="Location ecologically desirable but not in local strategy"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Area/compensation not in local strategy/ no local strategy" name="Area/compensation not in local strategy/ no local strategy"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat created in advance/years">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="0" name="0"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="1" name="1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="2" name="2"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="3" name="3"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="4" name="4"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="5" name="5"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="6" name="6"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="7" name="7"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="8" name="8"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="9" name="9"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="10" name="10"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="11" name="11"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="12" name="12"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="13" name="13"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="14" name="14"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="15" name="15"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="16" name="16"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="17" name="17"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="18" name="18"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="19" name="19"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="20" name="20"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="21" name="21"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="22" name="22"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="23" name="23"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="24" name="24"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="25" name="25"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="26" name="26"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="27" name="27"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="28" name="28"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="29" name="29"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="30" name="30"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="30+" name="30+"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Habitat already in target condition" name="Habitat already in target condition"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Delay in starting habitat creation/years">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="0" name="0"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="1" name="1"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="2" name="2"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="3" name="3"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="4" name="4"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="5" name="5"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="6" name="6"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="7" name="7"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="8" name="8"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="9" name="9"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="10" name="10"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="11" name="11"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="12" name="12"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="13" name="13"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="14" name="14"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="15" name="15"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="16" name="16"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="17" name="17"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="18" name="18"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="19" name="19"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="20" name="20"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="21" name="21"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="22" name="22"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="23" name="23"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="24" name="24"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="25" name="25"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="26" name="26"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="27" name="27"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="28" name="28"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="29" name="29"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="30" name="30"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="30+" name="30+"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="N/A" name="N/A"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Spatial risk category">
      <editWidget type="TextEdit"><config><Option/></config></editWidget>
    </field>
    <field name="Location">
      <editWidget type="ValueMap">
        <config>
          <Option type="Map">
            <Option type="List" name="map">
              <Option type="Map">
                <Option type="QString" value="On site" name="On site"/>
              </Option>
              <Option type="Map">
                <Option type="QString" value="Off site" name="Off site"/>
              </Option>
            </Option>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Site Name">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Survey Date">
      <editWidget type="DateTime">
        <config>
          <Option type="Map">
            <Option type="bool" value="true" name="allow_null"/>
            <Option type="bool" value="true" name="calendar_popup"/>
            <Option type="QString" value="yyyy-MM-dd" name="display_format"/>
            <Option type="QString" value="yyyy-MM-dd" name="field_format"/>
            <Option type="bool" value="false" name="field_iso_format"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Survey Details">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Comment">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Mapped by">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Company">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Base Map">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat Fixed Criteria - pre_Baseline UKHAB">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat Fixed Criteria - pre_Baseline Distinctivness">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat Fixed Criteria - post_Proposed UKHAB">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat Fixed Criteria - post_Proposed Distinctiveness">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Habitat retention descriptor - post_Descriptor">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="fid"/>
    <alias index="1" name="" field="Parcel Ref"/>
    <alias index="2" name="" field="Baseline Broad Habitat Type"/>
    <alias index="3" name="" field="Baseline Habitat Type"/>
    <alias index="4" name="" field="Area"/>
    <alias index="5" name="" field="Baseline Condition"/>
    <alias index="6" name="" field="Baseline Strategic Significance"/>
    <alias index="7" name="" field="Retention Category"/>
    <alias index="8" name="" field="Proposed Broad Habitat Type"/>
    <alias index="9" name="" field="Proposed Habitat Type"/>
    <alias index="10" name="" field="Proposed Condition"/>
    <alias index="11" name="" field="Proposed Strategic Significance"/>
    <alias index="12" name="" field="Habitat created in advance/years"/>
    <alias index="13" name="" field="Delay in starting habitat creation/years"/>
    <alias index="14" name="" field="Spatial risk category"/>
    <alias index="15" name="" field="Location"/>
    <alias index="16" name="" field="Site Name"/>
    <alias index="17" name="" field="Survey Date"/>
    <alias index="18" name="" field="Survey Details"/>
    <alias index="19" name="" field="Comment"/>
    <alias index="20" name="" field="Mapped by"/>
    <alias index="21" name="" field="Company"/>
    <alias index="22" name="" field="Base Map"/>
    <alias index="23" name="" field="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
    <alias index="24" name="Baseline Distinctiveness" field="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
    <alias index="25" name="Proposed UKHAB" field="Habitat Fixed Criteria - post_Proposed UKHAB"/>
    <alias index="26" name="Proposed Distinctiveness" field="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
    <alias index="27" name="Proposed Habitat Source" field="Habitat retention descriptor - post_Descriptor"/>
  </aliases>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="'Null'" applyOnUpdate="0" field="Parcel Ref"/>
    <default expression="'Null'" applyOnUpdate="0" field="Baseline Broad Habitat Type"/>
    <default expression="'Null'" applyOnUpdate="0" field="Baseline Habitat Type"/>
    <default expression="$area" applyOnUpdate="1" field="Area"/>
    <default expression="'Null'" applyOnUpdate="0" field="Baseline Condition"/>
    <default expression="'Null'" applyOnUpdate="0" field="Baseline Strategic Significance"/>
    <default expression="'Lost'" applyOnUpdate="0" field="Retention Category"/>
    <default expression="'Null'" applyOnUpdate="0" field="Proposed Broad Habitat Type"/>
    <default expression="'Null'" applyOnUpdate="0" field="Proposed Habitat Type"/>
    <default expression="'Null'" applyOnUpdate="0" field="Proposed Condition"/>
    <default expression="'Null'" applyOnUpdate="0" field="Proposed Strategic Significance"/>
    <default expression="0" applyOnUpdate="0" field="Habitat created in advance/years"/>
    <default expression="0" applyOnUpdate="0" field="Delay in starting habitat creation/years"/>
    <default expression="'N/A'" applyOnUpdate="0" field="Spatial risk category"/>
    <default expression="'On site'" applyOnUpdate="0" field="Location"/>
    <default expression="" applyOnUpdate="0" field="Site Name"/>
    <default expression="" applyOnUpdate="0" field="Survey Date"/>
    <default expression="" applyOnUpdate="0" field="Survey Details"/>
    <default expression="" applyOnUpdate="0" field="Comment"/>
    <default expression="" applyOnUpdate="0" field="Mapped by"/>
    <default expression="" applyOnUpdate="0" field="Company"/>
    <default expression="" applyOnUpdate="0" field="Base Map"/>
    <default expression="" applyOnUpdate="0" field="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
    <default expression="'N/A'" applyOnUpdate="0" field="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
    <default expression="'N/A'" applyOnUpdate="0" field="Habitat Fixed Criteria - post_Proposed UKHAB"/>
    <default expression="'N/A'" applyOnUpdate="0" field="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
    <default expression="" applyOnUpdate="0" field="Habitat retention descriptor - post_Descriptor"/>
  </defaults>
  <constraints>
    <constraint constraints="3" unique_strength="1" exp_strength="0" notnull_strength="1" field="fid"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Parcel Ref"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Baseline Broad Habitat Type"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Baseline Habitat Type"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Area"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Baseline Condition"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Baseline Strategic Significance"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Retention Category"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Proposed Broad Habitat Type"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Proposed Habitat Type"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Proposed Condition"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Proposed Strategic Significance"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Habitat created in advance/years"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Delay in starting habitat creation/years"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Spatial risk category"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Location"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Site Name"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Survey Date"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Survey Details"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Comment"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Mapped by"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Company"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Base Map"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Habitat Fixed Criteria - post_Proposed UKHAB"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
    <constraint constraints="0" unique_strength="0" exp_strength="0" notnull_strength="0" field="Habitat retention descriptor - post_Descriptor"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="Parcel Ref"/>
    <constraint exp="" desc="" field="Baseline Broad Habitat Type"/>
    <constraint exp="" desc="" field="Baseline Habitat Type"/>
    <constraint exp="" desc="" field="Area"/>
    <constraint exp="" desc="" field="Baseline Condition"/>
    <constraint exp="" desc="" field="Baseline Strategic Significance"/>
    <constraint exp="" desc="" field="Retention Category"/>
    <constraint exp="" desc="" field="Proposed Broad Habitat Type"/>
    <constraint exp="" desc="" field="Proposed Habitat Type"/>
    <constraint exp="" desc="" field="Proposed Condition"/>
    <constraint exp="" desc="" field="Proposed Strategic Significance"/>
    <constraint exp="" desc="" field="Habitat created in advance/years"/>
    <constraint exp="" desc="" field="Delay in starting habitat creation/years"/>
    <constraint exp="" desc="" field="Spatial risk category"/>
    <constraint exp="" desc="" field="Location"/>
    <constraint exp="" desc="" field="Site Name"/>
    <constraint exp="" desc="" field="Survey Date"/>
    <constraint exp="" desc="" field="Survey Details"/>
    <constraint exp="" desc="" field="Comment"/>
    <constraint exp="" desc="" field="Mapped by"/>
    <constraint exp="" desc="" field="Company"/>
    <constraint exp="" desc="" field="Base Map"/>
    <constraint exp="" desc="" field="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
    <constraint exp="" desc="" field="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
    <constraint exp="" desc="" field="Habitat Fixed Criteria - post_Proposed UKHAB"/>
    <constraint exp="" desc="" field="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
    <constraint exp="" desc="" field="Habitat retention descriptor - post_Descriptor"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;Habitat retention descriptor - post_Descriptor&quot;" sortOrder="1">
    <columns>
      <column type="field" width="-1" hidden="0" name="Parcel Ref"/>
      <column type="field" width="-1" hidden="1" name="Area"/>
      <column type="field" width="-1" hidden="0" name="Baseline Broad Habitat Type"/>
      <column type="field" width="-1" hidden="0" name="Baseline Habitat Type"/>
      <column type="field" width="100" hidden="1" name="Baseline Condition"/>
      <column type="field" width="201" hidden="1" name="Baseline Strategic Significance"/>
      <column type="field" width="220" hidden="1" name="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
      <column type="field" width="100" hidden="1" name="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
      <column type="field" width="100" hidden="0" name="Retention Category"/>
      <column type="field" width="131" hidden="1" name="Habitat retention descriptor - post_Descriptor"/>
      <column type="field" width="132" hidden="1" name="Proposed Broad Habitat Type"/>
      <column type="field" width="-1" hidden="1" name="Proposed Habitat Type"/>
      <column type="field" width="100" hidden="1" name="Proposed Condition"/>
      <column type="field" width="252" hidden="1" name="Proposed Strategic Significance"/>
      <column type="field" width="-1" hidden="1" name="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
      <column type="field" width="-1" hidden="1" name="Habitat Fixed Criteria - post_Proposed UKHAB"/>
      <column type="field" width="-1" hidden="1" name="Habitat created in advance/years"/>
      <column type="field" width="-1" hidden="1" name="Delay in starting habitat creation/years"/>
      <column type="field" width="-1" hidden="1" name="Location"/>
      <column type="field" width="-1" hidden="1" name="Spatial risk category"/>
      <column type="field" width="-1" hidden="1" name="fid"/>
      <column type="actions" width="-1" hidden="1"/>
      <column type="field" width="-1" hidden="1" name="Site Name"/>
      <column type="field" width="-1" hidden="1" name="Survey Date"/>
      <column type="field" width="-1" hidden="1" name="Survey Details"/>
      <column type="field" width="-1" hidden="1" name="Comment"/>
      <column type="field" width="-1" hidden="1" name="Mapped by"/>
      <column type="field" width="-1" hidden="1" name="Company"/>
      <column type="field" width="-1" hidden="1" name="Base Map"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles>
      <fieldstyle fieldname="Baseline Habitat Type"/>
      <fieldstyle fieldname="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
      <fieldstyle fieldname="Proposed Condition"/>
      <fieldstyle fieldname="Retention Category"/>
      <fieldstyle fieldname="Habitat retention descriptor - post_Descriptor"/>
      <fieldstyle fieldname="Location ">
        <style rule="@value ='On site'" background_color_alpha="255" background_color="#b2df8a" name="">
          <font description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
        </style>
        <style rule="@value ='Off site'" background_color_alpha="255" background_color="#fdbf6f" name="Off-site">
          <font description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
        </style>
      </fieldstyle>
      <fieldstyle fieldname="Baseline Condition"/>
      <fieldstyle fieldname="Proposed Broad Habitat Type"/>
      <fieldstyle fieldname="Delay in starting habitat creation/years"/>
      <fieldstyle fieldname="Area"/>
      <fieldstyle fieldname="Spatial risk category"/>
      <fieldstyle fieldname="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
      <fieldstyle fieldname="Baseline Broad Habitat Type"/>
      <fieldstyle fieldname="Habitat created in advance/years ">
        <style rule="&quot;Baseline Broad Habitat Type&quot;&lt;>0" background_color_alpha="255" background_color="#ffffff" name="White">
          <font description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
        </style>
      </fieldstyle>
      <fieldstyle fieldname="Proposed Strategic Significance"/>
      <fieldstyle fieldname="Proposed Habitat Type"/>
      <fieldstyle fieldname="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
      <fieldstyle fieldname="Parcel Ref"/>
      <fieldstyle fieldname="Baseline Strategic Significance"/>
      <fieldstyle fieldname="Location"/>
      <fieldstyle fieldname="Habitat Fixed Criteria - post_Proposed UKHAB"/>
      <fieldstyle fieldname="fid"/>
      <fieldstyle fieldname="Habitat created in advance/years"/>
    </fieldstyles>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <attributeEditorContainer visibilityExpression="" visibilityExpressionEnabled="0" name="Baseline" groupBox="0" columnCount="1" showLabel="1">
      <attributeEditorField index="1" name="Parcel Ref" showLabel="1"/>
      <attributeEditorField index="15" name="Location" showLabel="1"/>
      <attributeEditorField index="2" name="Baseline Broad Habitat Type" showLabel="1"/>
      <attributeEditorField index="3" name="Baseline Habitat Type" showLabel="1"/>
      <attributeEditorField index="5" name="Baseline Condition" showLabel="1"/>
      <attributeEditorField index="6" name="Baseline Strategic Significance" showLabel="1"/>
    </attributeEditorContainer>
    <attributeEditorContainer visibilityExpression="" visibilityExpressionEnabled="0" name="Proposed" groupBox="0" columnCount="1" showLabel="1">
      <attributeEditorField index="7" name="Retention Category" showLabel="1"/>
      <attributeEditorField index="8" name="Proposed Broad Habitat Type" showLabel="1"/>
      <attributeEditorField index="9" name="Proposed Habitat Type" showLabel="1"/>
      <attributeEditorField index="10" name="Proposed Condition" showLabel="1"/>
      <attributeEditorField index="11" name="Proposed Strategic Significance" showLabel="1"/>
      <attributeEditorField index="12" name="Habitat created in advance/years" showLabel="1"/>
      <attributeEditorField index="13" name="Delay in starting habitat creation/years" showLabel="1"/>
      <attributeEditorField index="14" name="Spatial risk category" showLabel="1"/>
    </attributeEditorContainer>
    <attributeEditorContainer visibilityExpression="" visibilityExpressionEnabled="0" name="Assessment Details" groupBox="0" columnCount="1" showLabel="1">
      <attributeEditorField index="16" name="Site Name" showLabel="1"/>
      <attributeEditorField index="17" name="Survey Date" showLabel="1"/>
      <attributeEditorField index="18" name="Survey Details" showLabel="1"/>
      <attributeEditorField index="19" name="Comment" showLabel="1"/>
      <attributeEditorField index="20" name="Mapped by" showLabel="1"/>
      <attributeEditorField index="21" name="Company" showLabel="1"/>
      <attributeEditorField index="22" name="Base Map" showLabel="1"/>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="Area"/>
    <field editable="1" name="Base Map"/>
    <field editable="1" name="Baseline Broad Habitat Type"/>
    <field editable="1" name="Baseline Condition"/>
    <field editable="1" name="Baseline Habitat Type"/>
    <field editable="1" name="Baseline Strategic Significance"/>
    <field editable="1" name="Comment"/>
    <field editable="1" name="Company"/>
    <field editable="1" name="Delay in starting habitat creation/years"/>
    <field editable="0" name="Habitat Fixed Criteria - post_Proposed Distinctiveness"/>
    <field editable="0" name="Habitat Fixed Criteria - post_Proposed UKHAB"/>
    <field editable="0" name="Habitat Fixed Criteria - pre_Baseline Distinctivness"/>
    <field editable="0" name="Habitat Fixed Criteria - pre_Baseline UKHAB"/>
    <field editable="1" name="Habitat created in advance/years"/>
    <field editable="1" name="Habitat created in advance/years "/>
    <field editable="0" name="Habitat retention descriptor - post_Descriptor"/>
    <field editable="1" name="Location"/>
    <field editable="1" name="Location "/>
    <field editable="1" name="Mapped by"/>
    <field editable="1" name="Parcel Ref"/>
    <field editable="1" name="Proposed  Condition"/>
    <field editable="1" name="Proposed  Strategic Significance"/>
    <field editable="1" name="Proposed Broad Habitat Type"/>
    <field editable="1" name="Proposed Condition"/>
    <field editable="1" name="Proposed Habitat Type"/>
    <field editable="1" name="Proposed Strategic Significance"/>
    <field editable="1" name="Retention Category"/>
    <field editable="1" name="Site Name"/>
    <field editable="1" name="Spatial risk category"/>
    <field editable="1" name="Survey Date"/>
    <field editable="1" name="Survey Details"/>
    <field editable="1" name="fid"/>
  </editable>
  <labelOnTop>
    <field name="Area" labelOnTop="0"/>
    <field name="Base Map" labelOnTop="0"/>
    <field name="Baseline Broad Habitat Type" labelOnTop="0"/>
    <field name="Baseline Condition" labelOnTop="0"/>
    <field name="Baseline Habitat Type" labelOnTop="0"/>
    <field name="Baseline Strategic Significance" labelOnTop="0"/>
    <field name="Comment" labelOnTop="0"/>
    <field name="Company" labelOnTop="0"/>
    <field name="Delay in starting habitat creation/years" labelOnTop="0"/>
    <field name="Habitat Fixed Criteria - post_Proposed Distinctiveness" labelOnTop="0"/>
    <field name="Habitat Fixed Criteria - post_Proposed UKHAB" labelOnTop="0"/>
    <field name="Habitat Fixed Criteria - pre_Baseline Distinctivness" labelOnTop="0"/>
    <field name="Habitat Fixed Criteria - pre_Baseline UKHAB" labelOnTop="0"/>
    <field name="Habitat created in advance/years" labelOnTop="0"/>
    <field name="Habitat created in advance/years " labelOnTop="0"/>
    <field name="Habitat retention descriptor - post_Descriptor" labelOnTop="0"/>
    <field name="Location" labelOnTop="0"/>
    <field name="Location " labelOnTop="0"/>
    <field name="Mapped by" labelOnTop="0"/>
    <field name="Parcel Ref" labelOnTop="0"/>
    <field name="Proposed  Condition" labelOnTop="0"/>
    <field name="Proposed  Strategic Significance" labelOnTop="0"/>
    <field name="Proposed Broad Habitat Type" labelOnTop="0"/>
    <field name="Proposed Condition" labelOnTop="0"/>
    <field name="Proposed Habitat Type" labelOnTop="0"/>
    <field name="Proposed Strategic Significance" labelOnTop="0"/>
    <field name="Retention Category" labelOnTop="0"/>
    <field name="Site Name" labelOnTop="0"/>
    <field name="Spatial risk category" labelOnTop="0"/>
    <field name="Survey Date" labelOnTop="0"/>
    <field name="Survey Details" labelOnTop="0"/>
    <field name="fid" labelOnTop="0"/>
  </labelOnTop>
  <widgets/>
  <previewExpression>"Baseline Broad Habitat Type"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
